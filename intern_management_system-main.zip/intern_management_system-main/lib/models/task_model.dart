import 'package:cloud_firestore/cloud_firestore.dart';

class TaskModel {
  const TaskModel({
    this.id = '',
    required this.title,
    required this.description,
    required this.assignedTo,
    required this.assignedToName,
    required this.dueDate,
    this.status = 'pending',
    this.progress = 0,
    this.priority = 'medium',
  });

  final String id;
  final String title;
  final String description;
  final String assignedTo;
  final String assignedToName;
  final DateTime dueDate;
  final String status;
  final int progress;
  final String priority;

  factory TaskModel.fromMap(String id, Map<String, dynamic> map) {
    final timestamp = map['dueDate'];
    final rawProgress = map['progress'];
    return TaskModel(
      id: id,
      title: map['title'] as String? ?? '',
      description: map['description'] as String? ?? '',
      assignedTo: map['assignedTo'] as String? ?? '',
      assignedToName: map['assignedToName'] as String? ?? '',
      dueDate: timestamp is Timestamp ? timestamp.toDate() : DateTime.now(),
      status: map['status'] as String? ?? 'pending',
      progress: rawProgress is num ? rawProgress.toInt() : 0,
      priority: switch (map['priority']) {
        'high' => 'high',
        'low' => 'low',
        _ => 'medium',
      },
    );
  }

  Map<String, dynamic> toMap() => {
    'title': title,
    'description': description,
    'assignedTo': assignedTo,
    'assignedToName': assignedToName,
    'dueDate': Timestamp.fromDate(dueDate),
    'status': status,
    'progress': progress,
    'priority': priority,
    'createdAt': FieldValue.serverTimestamp(),
  };
}
