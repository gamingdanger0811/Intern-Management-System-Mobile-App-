import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  final String uid;
  final String name;
  final String email;
  final String role;
  final String department;
  final String phone;
  final String university;
  final String semester;
  final String domain;
  final DateTime? joinDate;
  final int durationMonths;
  final String status;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.role,
    this.department = '',
    this.phone = '',
    this.university = '',
    this.semester = '',
    this.domain = '',
    this.joinDate,
    this.durationMonths = 3,
    this.status = 'active',
  });

  factory UserModel.fromMap(String uid, Map<String, dynamic> map) {
    final rawJoinDate = map['joinDate'];
    final rawDuration = map['durationMonths'];
    return UserModel(
      uid: uid,
      name: map['name'] as String? ?? '',
      email: map['email'] as String? ?? '',
      role: map['role'] as String? ?? 'intern',
      department: map['department'] as String? ?? '',
      phone: map['phone'] as String? ?? '',
      university: map['university'] as String? ?? '',
      semester: map['semester'] as String? ?? '',
      domain: map['domain'] as String? ?? '',
      joinDate: rawJoinDate is Timestamp ? rawJoinDate.toDate() : null,
      durationMonths: rawDuration is num ? rawDuration.toInt() : 3,
      status: map['status'] as String? ?? 'active',
    );
  }

  Map<String, dynamic> toMap() => {
    'name': name,
    'email': email,
    'role': role,
    'department': department,
    'phone': phone,
    'university': university,
    'semester': semester,
    'domain': domain,
    'joinDate': joinDate == null ? null : Timestamp.fromDate(joinDate!),
    'durationMonths': durationMonths,
    'status': status,
  };
}
