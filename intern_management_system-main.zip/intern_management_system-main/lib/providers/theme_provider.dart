import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider extends ChangeNotifier {
  static const _key = 'themeMode';

  ThemeMode _mode = ThemeMode.light;
  Object? _loadError;

  ThemeProvider() {
    _load();
  }

  ThemeMode get mode => _mode;
  Object? get loadError => _loadError;

  Future<void> _load() async {
    try {
      final preferences = await SharedPreferences.getInstance();
      _mode = preferences.getString(_key) == 'dark'
          ? ThemeMode.dark
          : ThemeMode.light;
    } catch (error) {
      _loadError = error;
      debugPrint('Could not load theme preference: $error');
    }
    notifyListeners();
  }

  Future<void> setMode(ThemeMode mode) async {
    _mode = mode == ThemeMode.dark ? ThemeMode.dark : ThemeMode.light;
    notifyListeners();

    final preferences = await SharedPreferences.getInstance();
    await preferences.setString(
      _key,
      _mode == ThemeMode.dark ? 'dark' : 'light',
    );
    _loadError = null;
  }
}
