import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';
import 'providers/theme_provider.dart';
import 'screens/splash_screen.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MyApp(
      firebaseInitialization: Firebase.initializeApp(
        options: kIsWeb ? DefaultFirebaseOptions.web : null,
      ),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key, required this.firebaseInitialization});

  final Future<FirebaseApp> firebaseInitialization;

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ThemeProvider(),
      child: _AppShell(firebaseInitialization: firebaseInitialization),
    );
  }
}

class _AppShell extends StatelessWidget {
  const _AppShell({required this.firebaseInitialization});

  final Future<FirebaseApp> firebaseInitialization;

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();
    return FutureBuilder<FirebaseApp>(
      future: firebaseInitialization,
      builder: (context, firebaseSnapshot) {
        if (firebaseSnapshot.connectionState == ConnectionState.waiting) {
          return const MaterialApp(
            debugShowCheckedModeBanner: false,
            home: Scaffold(body: Center(child: CircularProgressIndicator())),
          );
        }
        if (firebaseSnapshot.hasError) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            home: Scaffold(
              body: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    'Firebase initialize nahi ho saka: '
                    '${firebaseSnapshot.error}\n\n'
                    'Firebase project configuration check karein.',
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          );
        }
        return MaterialApp(
          title: 'Intern Management System',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.light,
          darkTheme: AppTheme.dark,
          themeMode: theme.mode,
          builder: (context, child) {
            if (!kIsWeb) return child!;
            final dark = Theme.of(context).brightness == Brightness.dark;
            return ColoredBox(
              color: dark ? Colors.black : const Color(0xFFE5E7EB),
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 430),
                  child: ClipRect(child: child),
                ),
              ),
            );
          },
          home: const SplashScreen(),
        );
      },
    );
  }
}
