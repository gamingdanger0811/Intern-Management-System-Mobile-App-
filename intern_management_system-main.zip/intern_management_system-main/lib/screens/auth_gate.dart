import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../models/user_model.dart';
import '../services/auth_service.dart';
import 'admin/admin_home.dart';
import 'intern/intern_home.dart';
import 'login_screen.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: AuthService().authChanges,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.hasError) {
          return _AuthErrorScreen(message: 'Auth error: ${snapshot.error}');
        }
        final firebaseUser = snapshot.data;
        if (firebaseUser == null) return const LoginScreen();
        return _UserProfileGate(
          key: ValueKey(firebaseUser.uid),
          uid: firebaseUser.uid,
        );
      },
    );
  }
}

class _UserProfileGate extends StatefulWidget {
  const _UserProfileGate({super.key, required this.uid});

  final String uid;

  @override
  State<_UserProfileGate> createState() => _UserProfileGateState();
}

class _UserProfileGateState extends State<_UserProfileGate> {
  late Future<UserModel?> _userFuture;

  @override
  void initState() {
    super.initState();
    _userFuture = AuthService().getUser(widget.uid);
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<UserModel?>(
      future: _userFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.hasError) {
          return _AuthErrorScreen(
            message: 'User record load nahi hua: ${snapshot.error}',
            onRetry: () =>
                setState(() => _userFuture = AuthService().getUser(widget.uid)),
          );
        }
        final user = snapshot.data;
        if (user == null) {
          return const _AuthErrorScreen(
            message: 'User ka record nahi mila. Admin se rabta karein.',
          );
        }
        return user.role == 'admin'
            ? AdminHome(admin: user)
            : InternHome(intern: user);
      },
    );
  }
}

class _AuthErrorScreen extends StatelessWidget {
  const _AuthErrorScreen({required this.message, this.onRetry});

  final String message;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(message, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              if (onRetry != null)
                OutlinedButton(onPressed: onRetry, child: const Text('Retry')),
              ElevatedButton(
                onPressed: AuthService().signOut,
                child: const Text('Sign out'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
