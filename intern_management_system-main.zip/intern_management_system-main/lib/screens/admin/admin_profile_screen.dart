import 'package:flutter/material.dart';

import '../../models/task_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_widgets.dart';
import '../../widgets/confirm_logout.dart';
import '../../widgets/theme_selector.dart';

class AdminProfileScreen extends StatefulWidget {
  const AdminProfileScreen({super.key, required this.admin});

  final UserModel admin;

  @override
  State<AdminProfileScreen> createState() => _AdminProfileScreenState();
}

class _AdminProfileScreenState extends State<AdminProfileScreen> {
  late String _name = widget.admin.name;
  late String _phone = widget.admin.phone;
  late String _department = widget.admin.department;

  Widget _row(IconData icon, String label, String value) {
    return ListTile(
      leading: Icon(icon, color: AppTheme.primary),
      title: Text(label, style: const TextStyle(fontSize: 12)),
      subtitle: Text(
        value.isEmpty ? '-' : value,
        style: const TextStyle(fontSize: 16),
      ),
    );
  }

  Future<void> _edit() async {
    final nameC = TextEditingController(text: _name);
    final phoneC = TextEditingController(text: _phone);
    final deptC = TextEditingController(text: _department);
    final formKey = GlobalKey<FormState>();

    try {
      final saved = await showModalBottomSheet<bool>(
        context: context,
        isScrollControlled: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        builder: (ctx) => Padding(
          padding: EdgeInsets.fromLTRB(
            20,
            20,
            20,
            MediaQuery.of(ctx).viewInsets.bottom + 20,
          ),
          child: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Edit Profile',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: nameC,
                    decoration: const InputDecoration(
                      labelText: 'Name',
                      prefixIcon: Icon(Icons.person_outline),
                    ),
                    validator: (value) =>
                        (value == null || value.trim().isEmpty)
                        ? 'Required'
                        : null,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: phoneC,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'Phone',
                      prefixIcon: Icon(Icons.phone_outlined),
                    ),
                    validator: (value) =>
                        (value != null &&
                            value.trim().isNotEmpty &&
                            value.trim().length < 10)
                        ? 'Enter a valid phone number'
                        : null,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: deptC,
                    decoration: const InputDecoration(
                      labelText: 'Department / Position',
                      prefixIcon: Icon(Icons.business_outlined),
                    ),
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        if (formKey.currentState!.validate()) {
                          Navigator.pop(ctx, true);
                        }
                      },
                      child: const Text('Save'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );

      if (saved == true) {
        await FirestoreService().updateIntern(widget.admin.uid, {
          'name': nameC.text.trim(),
          'phone': phoneC.text.trim(),
          'department': deptC.text.trim(),
        });
        if (!mounted) return;
        setState(() {
          _name = nameC.text.trim();
          _phone = phoneC.text.trim();
          _department = deptC.text.trim();
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile updated')),
        );
      }
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Error: $error')));
    } finally {
      nameC.dispose();
      phoneC.dispose();
      deptC.dispose();
    }
  }

  @override
  Widget build(BuildContext context) {
    final fs = FirestoreService();
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
        actions: [IconButton(icon: const Icon(Icons.edit), onPressed: _edit)],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: CircleAvatar(
              radius: 44,
              backgroundColor: AppTheme.primary.withValues(alpha: 0.12),
              child: Text(
                _name.isNotEmpty ? _name[0].toUpperCase() : '?',
                style: const TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primary,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(
              _name,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 4),
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.primary.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text(
                'Administrator',
                style: TextStyle(
                  color: AppTheme.primary,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          StreamBuilder<List<UserModel>>(
            stream: fs.internsStream(),
            builder: (context, internSnap) {
              return StreamBuilder<List<TaskModel>>(
                stream: fs.allTasksStream(),
                builder: (context, taskSnap) {
                  final tasks = taskSnap.data ?? [];
                  final done = tasks
                      .where((task) => task.status == 'completed')
                      .length;
                  return Row(
                    children: [
                      StatCard(
                        label: 'Interns',
                        value: '${internSnap.data?.length ?? 0}',
                        icon: Icons.people,
                        color: AppTheme.primary,
                      ),
                      const SizedBox(width: 12),
                      StatCard(
                        label: 'Tasks Assigned',
                        value: '${tasks.length}',
                        icon: Icons.assignment,
                        color: AppTheme.warning,
                      ),
                      const SizedBox(width: 12),
                      StatCard(
                        label: 'Completed',
                        value: '$done',
                        icon: Icons.check_circle,
                        color: AppTheme.success,
                      ),
                    ],
                  );
                },
              );
            },
          ),
          const SizedBox(height: 16),
          AppCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                _row(Icons.email, 'Email', widget.admin.email),
                _row(Icons.phone, 'Phone', _phone),
                _row(Icons.business, 'Department / Position', _department),
                _row(Icons.badge, 'Role', 'Administrator'),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const ThemeSelectorCard(),
          const SizedBox(height: 24),
          SizedBox(
            height: 50,
            child: OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.danger,
                side: const BorderSide(color: AppTheme.danger),
              ),
              icon: const Icon(Icons.logout),
              label: const Text('Log out'),
              onPressed: () => confirmLogout(context),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}
