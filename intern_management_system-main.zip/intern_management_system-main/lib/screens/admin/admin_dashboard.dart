import 'package:flutter/material.dart';

import '../../models/task_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../widgets/app_widgets.dart';
import 'add_intern_screen.dart';
import 'intern_list_screen.dart';

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key, required this.admin});

  final UserModel admin;

  Widget _stat(String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            children: [
              Icon(icon, color: color),
              const SizedBox(height: 4),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(label, style: const TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _navigation(
    BuildContext context,
    String title,
    IconData icon,
    Widget page,
  ) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right),
        onTap: () =>
            Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final firestore = FirestoreService();
    return Scaffold(
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          GradientHeader(
            subtitle: 'Welcome back,',
            title: admin.name,
          ),
          const SizedBox(height: 16),
          StreamBuilder<List<UserModel>>(
            stream: firestore.internsStream(),
            builder: (context, internSnapshot) {
              return StreamBuilder<List<TaskModel>>(
                stream: firestore.allTasksStream(),
                builder: (context, taskSnapshot) {
                  if (internSnapshot.hasError || taskSnapshot.hasError) {
                    return Card(
                      child: ListTile(
                        title: const Text('Dashboard stats load nahi huay'),
                        subtitle: Text(
                          '${internSnapshot.error ?? taskSnapshot.error}',
                        ),
                      ),
                    );
                  }
                  final tasks = taskSnapshot.data ?? [];
                  final completed = tasks
                      .where((task) => task.status == 'completed')
                      .length;
                  final completionPercent = tasks.isEmpty
                      ? 0
                      : (completed / tasks.length * 100).round();
                  return Row(
                    children: [
                      _stat(
                        'Interns',
                        '${internSnapshot.data?.length ?? 0}',
                        Icons.people,
                        Colors.indigo,
                      ),
                      _stat(
                        'Tasks',
                        '${tasks.length}',
                        Icons.assignment,
                        Colors.orange,
                      ),
                      _stat(
                        'Completed',
                        '$completionPercent%',
                        Icons.check_circle,
                        Colors.green,
                      ),
                    ],
                  );
                },
              );
            },
          ),
          _navigation(
            context,
            'View Interns',
            Icons.list_alt,
            const InternListScreen(),
          ),
          _navigation(
            context,
            'Add Intern',
            Icons.person_add,
            const AddInternScreen(),
          ),
        ],
      ),
    );
  }
}
