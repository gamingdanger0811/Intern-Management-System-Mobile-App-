import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../models/task_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';

class AssignTaskScreen extends StatefulWidget {
  final String? internUid;
  const AssignTaskScreen({super.key, this.internUid});

  @override
  State<AssignTaskScreen> createState() => _AssignTaskScreenState();
}

class _AssignTaskScreenState extends State<AssignTaskScreen> {
  final _formKey = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _fs = FirestoreService();
  final Set<String> _selected = {};
  DateTime? _dueDate;
  String _priority = 'medium';
  bool _loading = false;
  bool _selectError = false;

  @override
  void initState() {
    super.initState();
    if (widget.internUid != null) _selected.add(widget.internUid!);
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 1)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (d != null) setState(() => _dueDate = d);
  }

  Future<void> _pickInterns(List<UserModel> interns) async {
    final temp = Set<String>.from(_selected);
    final result = await showModalBottomSheet<Set<String>>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
                maxHeight: MediaQuery.of(ctx).size.height * 0.75),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 8, 0),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text('Select interns',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold)),
                      ),
                      TextButton(
                        onPressed: () => setSheet(() {
                          if (temp.length == interns.length) {
                            temp.clear();
                          } else {
                            temp
                              ..clear()
                              ..addAll(interns.map((u) => u.uid));
                          }
                        }),
                        child: Text(temp.length == interns.length
                            ? 'Clear all'
                            : 'Select all'),
                      ),
                    ],
                  ),
                ),
                Flexible(
                  child: ListView(
                    shrinkWrap: true,
                    children: interns
                        .map((u) => CheckboxListTile(
                              value: temp.contains(u.uid),
                              title: Text(u.name),
                              subtitle:
                                  Text(u.domain.isEmpty ? u.email : u.domain),
                              onChanged: (v) => setSheet(() {
                                if (v == true) {
                                  temp.add(u.uid);
                                } else {
                                  temp.remove(u.uid);
                                }
                              }),
                            ))
                        .toList(),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                  child: SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () => Navigator.pop(ctx, temp),
                      child: Text('Done (${temp.length} selected)'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    if (result != null) {
      setState(() {
        _selected
          ..clear()
          ..addAll(result);
        _selectError = false;
      });
    }
  }

  Future<void> _save(List<UserModel> interns) async {
    final valid = _formKey.currentState!.validate();
    if (_selected.isEmpty) setState(() => _selectError = true);
    if (!valid || _selected.isEmpty) return;
    if (_dueDate == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Select a due date')));
      return;
    }

    final chosen = interns.where((u) => _selected.contains(u.uid)).toList();
    setState(() => _loading = true);
    try {
      await _fs.addTasks(chosen
          .map((u) => TaskModel(
                title: _title.text.trim(),
                description: _desc.text.trim(),
                assignedTo: u.uid,
                assignedToName: u.name,
                dueDate: _dueDate!,
                priority: _priority,
              ))
          .toList());
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(chosen.length == 1
              ? 'Task assigned'
              : 'Task assigned to ${chosen.length} interns')));
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Could not assign task'),
          content: Text('$e'),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK')),
          ],
        ),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Assign Task')),
      body: StreamBuilder<List<UserModel>>(
        stream: _fs.internsStream(),
        builder: (context, snap) {
          if (snap.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text('Could not load interns:\n${snap.error}',
                    textAlign: TextAlign.center),
              ),
            );
          }
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final interns = snap.data ?? [];
          if (interns.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.groups_outlined,
                        size: 72, color: Colors.grey.shade400),
                    const SizedBox(height: 8),
                    const Text('No interns found',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Text(
                        'Add an intern first (Dashboard > Add Intern), '
                        'or ask the intern to create an account.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey.shade600)),
                  ],
                ),
              ),
            );
          }

          final selectedInterns =
              interns.where((u) => _selected.contains(u.uid)).toList();

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => _pickInterns(interns),
                    child: InputDecorator(
                      decoration: InputDecoration(
                        labelText: 'Assign To',
                        prefixIcon: const Icon(Icons.group_add_outlined),
                        suffixIcon: const Icon(Icons.arrow_drop_down),
                        errorText:
                            _selectError ? 'Select at least one intern' : null,
                      ),
                      child: selectedInterns.isEmpty
                          ? Text('Select interns',
                              style: TextStyle(color: Colors.grey.shade600))
                          : Wrap(
                              spacing: 6,
                              runSpacing: 4,
                              children: selectedInterns
                                  .map((u) => Chip(
                                        label: Text(u.name),
                                        visualDensity: VisualDensity.compact,
                                        onDeleted: () => setState(
                                            () => _selected.remove(u.uid)),
                                      ))
                                  .toList(),
                            ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _title,
                    decoration: const InputDecoration(
                        labelText: 'Task Title',
                        prefixIcon: Icon(Icons.title)),
                    validator: (v) =>
                        (v == null || v.trim().isEmpty) ? 'Required' : null,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _desc,
                    maxLines: 4,
                    decoration: const InputDecoration(
                        labelText: 'Description',
                        alignLabelWithHint: true,
                        prefixIcon: Padding(
                          padding: EdgeInsets.only(bottom: 56),
                          child: Icon(Icons.notes),
                        )),
                  ),
                  const SizedBox(height: 14),
                  InkWell(
                    onTap: _pickDate,
                    child: InputDecorator(
                      decoration: const InputDecoration(
                          labelText: 'Due Date',
                          prefixIcon: Icon(Icons.event)),
                      child: Text(_dueDate == null
                          ? 'Select a date'
                          : DateFormat('dd MMM yyyy').format(_dueDate!)),
                    ),
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(value: 'low', label: Text('Low')),
                        ButtonSegment(value: 'medium', label: Text('Medium')),
                        ButtonSegment(value: 'high', label: Text('High')),
                      ],
                      selected: {_priority},
                      onSelectionChanged: (s) =>
                          setState(() => _priority = s.first),
                    ),
                  ),
                  const SizedBox(height: 28),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton.icon(
                      onPressed: _loading ? null : () => _save(interns),
                      icon: _loading
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white))
                          : const Icon(Icons.add_task),
                      label: Text(_selected.length > 1
                          ? 'Assign to ${_selected.length} interns'
                          : 'Assign Task'),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
