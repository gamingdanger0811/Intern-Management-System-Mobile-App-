import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

import '../../models/user_model.dart';
import '../../services/firestore_service.dart';

class AddInternScreen extends StatefulWidget {
  final UserModel? intern;

  const AddInternScreen({super.key, this.intern});

  @override
  State<AddInternScreen> createState() => _AddInternScreenState();
}

class _AddInternScreenState extends State<AddInternScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _department = TextEditingController();
  final _phone = TextEditingController();
  final _university = TextEditingController();
  String? _semester;
  String? _domain;
  int _duration = 3;
  String _status = 'active';
  DateTime _joinDate = DateTime.now();
  bool _loading = false;

  bool get _isEdit => widget.intern != null;

  static const _semesters = ['1', '2', '3', '4', '5', '6', '7', '8'];
  static const _domains = [
    'Flutter',
    'Web Development',
    'Android',
    'AI / ML',
    'Data Science',
    'Cyber Security',
    'UI/UX',
    'Other',
  ];

  @override
  void initState() {
    super.initState();
    final intern = widget.intern;
    if (intern != null) {
      _name.text = intern.name;
      _email.text = intern.email;
      _department.text = intern.department;
      _phone.text = intern.phone;
      _university.text = intern.university;
      _semester = _semesters.contains(intern.semester) ? intern.semester : null;
      _domain = _domains.contains(intern.domain) ? intern.domain : null;
      _duration = [1, 2, 3, 6].contains(intern.durationMonths)
          ? intern.durationMonths
          : 3;
      _status = ['active', 'completed'].contains(intern.status)
          ? intern.status
          : 'active';
      _joinDate = intern.joinDate ?? DateTime.now();
    }
  }

  Future<void> _pickDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _joinDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (date != null) setState(() => _joinDate = date);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);

    final data = {
      'name': _name.text.trim(),
      'department': _department.text.trim(),
      'phone': _phone.text.trim(),
      'university': _university.text.trim(),
      'semester': _semester ?? '',
      'domain': _domain ?? '',
      'joinDate': Timestamp.fromDate(_joinDate),
      'durationMonths': _duration,
      'status': _status,
    };

    try {
      final firestore = FirestoreService();
      if (_isEdit) {
        await firestore.updateIntern(widget.intern!.uid, data);
      } else {
        await firestore.addIntern(
          email: _email.text,
          password: _password.text,
          data: data,
        );
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _isEdit ? 'Intern update ho gaya' : 'Intern add ho gaya',
          ),
        ),
      );
      Navigator.pop(context);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String? _required(String? value) =>
      value == null || value.trim().isEmpty ? 'Zaroori hai' : null;

  Widget _gap() => const SizedBox(height: 14);

  Widget _section(BuildContext context, String title) => Padding(
    padding: const EdgeInsets.only(top: 12, bottom: 10),
    child: Text(
      title,
      style: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.bold,
        color: Theme.of(context).colorScheme.primary,
      ),
    ),
  );

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    _department.dispose();
    _phone.dispose();
    _university.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Edit Intern' : 'Add Intern')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _section(context, 'Account'),
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(
                  labelText: 'Full Name',
                  prefixIcon: Icon(Icons.person_outline),
                ),
                validator: _required,
              ),
              _gap(),
              TextFormField(
                controller: _email,
                enabled: !_isEdit,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  prefixIcon: Icon(Icons.email_outlined),
                ),
                validator: (value) => value != null && value.contains('@')
                    ? null
                    : 'Sahi email likho',
              ),
              if (!_isEdit) ...[
                _gap(),
                TextFormField(
                  controller: _password,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Password',
                    prefixIcon: Icon(Icons.lock_outline),
                  ),
                  validator: (value) => value != null && value.length >= 6
                      ? null
                      : 'Kam az kam 6 characters',
                ),
              ],
              _gap(),
              TextFormField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'Phone Number',
                  prefixIcon: Icon(Icons.phone_outlined),
                ),
                validator: (value) => value != null && value.trim().length >= 10
                    ? null
                    : 'Sahi phone number likho',
              ),
              _section(context, 'Education'),
              TextFormField(
                controller: _university,
                decoration: const InputDecoration(
                  labelText: 'University',
                  prefixIcon: Icon(Icons.school_outlined),
                ),
                validator: _required,
              ),
              _gap(),
              DropdownButtonFormField<String>(
                initialValue: _semester,
                decoration: const InputDecoration(
                  labelText: 'Semester',
                  prefixIcon: Icon(Icons.format_list_numbered),
                ),
                items: _semesters
                    .map(
                      (semester) => DropdownMenuItem(
                        value: semester,
                        child: Text('Semester $semester'),
                      ),
                    )
                    .toList(),
                onChanged: (value) => setState(() => _semester = value),
                validator: (value) => value == null ? 'Semester chuno' : null,
              ),
              _section(context, 'Internship'),
              TextFormField(
                controller: _department,
                decoration: const InputDecoration(
                  labelText: 'Department',
                  prefixIcon: Icon(Icons.business_outlined),
                ),
                validator: _required,
              ),
              _gap(),
              DropdownButtonFormField<String>(
                initialValue: _domain,
                decoration: const InputDecoration(
                  labelText: 'Domain / Skill',
                  prefixIcon: Icon(Icons.code),
                ),
                items: _domains
                    .map(
                      (domain) =>
                          DropdownMenuItem(value: domain, child: Text(domain)),
                    )
                    .toList(),
                onChanged: (value) => setState(() => _domain = value),
                validator: (value) => value == null ? 'Domain chuno' : null,
              ),
              _gap(),
              InkWell(
                onTap: _pickDate,
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'Joining Date',
                    prefixIcon: Icon(Icons.calendar_today),
                  ),
                  child: Text(DateFormat('dd MMM yyyy').format(_joinDate)),
                ),
              ),
              _gap(),
              DropdownButtonFormField<int>(
                initialValue: _duration,
                decoration: const InputDecoration(
                  labelText: 'Duration',
                  prefixIcon: Icon(Icons.timelapse),
                ),
                items: [1, 2, 3, 6]
                    .map(
                      (months) => DropdownMenuItem(
                        value: months,
                        child: Text('$months month${months > 1 ? 's' : ''}'),
                      ),
                    )
                    .toList(),
                onChanged: (value) {
                  if (value != null) setState(() => _duration = value);
                },
              ),
              if (_isEdit) ...[
                _gap(),
                DropdownButtonFormField<String>(
                  initialValue: _status,
                  decoration: const InputDecoration(
                    labelText: 'Status',
                    prefixIcon: Icon(Icons.flag_outlined),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'active', child: Text('Active')),
                    DropdownMenuItem(
                      value: 'completed',
                      child: Text('Completed'),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) setState(() => _status = value);
                  },
                ),
              ],
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: _loading ? null : _save,
                  child: _loading
                      ? const SizedBox(
                          height: 22,
                          width: 22,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Text(_isEdit ? 'Update Intern' : 'Create Account'),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }
}
