import 'package:flutter/material.dart';

import '../../models/task_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_widgets.dart';
import '../../widgets/intern_progress_chart.dart';
import '../../widgets/status_pie_card.dart';
import '../../widgets/task_card.dart';

class AdminInsightsScreen extends StatelessWidget {
  const AdminInsightsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = FirestoreService();
    return Scaffold(
      appBar: AppBar(title: const Text('Insights')),
      body: StreamBuilder<List<UserModel>>(
        stream: firestore.internsStream(),
        builder: (context, internSnapshot) {
          return StreamBuilder<List<TaskModel>>(
            stream: firestore.allTasksStream(),
            builder: (context, taskSnapshot) {
              if (taskSnapshot.connectionState == ConnectionState.waiting ||
                  internSnapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (taskSnapshot.hasError || internSnapshot.hasError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      'Could not load insights:\n'
                      '${taskSnapshot.error ?? internSnapshot.error}',
                      textAlign: TextAlign.center,
                    ),
                  ),
                );
              }

              final interns = internSnapshot.data ?? [];
              final tasks = taskSnapshot.data ?? [];
              if (tasks.isEmpty) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.insights_outlined,
                          size: 72,
                          color: Colors.grey.shade400,
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'No insights yet',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Assign tasks to interns to see insights here.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.grey.shade600),
                        ),
                      ],
                    ),
                  ),
                );
              }

              final now = DateTime.now();
              final completed = tasks
                  .where((task) => task.status == 'completed')
                  .length;
              final completion = (completed / tasks.length * 100).round();
              final overdueTasks = tasks
                  .where(
                    (task) =>
                        task.status != 'completed' &&
                        task.dueDate.isBefore(now),
                  )
                  .toList();

              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      StatCard(
                        label: 'Interns',
                        value: '${interns.length}',
                        icon: Icons.people,
                        color: AppTheme.primary,
                      ),
                      const SizedBox(width: 12),
                      StatCard(
                        label: 'Completion',
                        value: '$completion%',
                        icon: Icons.check_circle,
                        color: AppTheme.success,
                      ),
                      const SizedBox(width: 12),
                      StatCard(
                        label: 'Overdue',
                        value: '${overdueTasks.length}',
                        icon: Icons.warning_amber_rounded,
                        color: AppTheme.danger,
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  StatusPieCard(tasks: tasks),
                  const SizedBox(height: 16),
                  InternProgressChart(interns: interns, tasks: tasks),
                  if (overdueTasks.isNotEmpty) ...[
                    const SizedBox(height: 24),
                    const Text(
                      'Needs Attention',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Overdue tasks',
                      style: TextStyle(color: Colors.grey.shade600),
                    ),
                    const SizedBox(height: 12),
                    ...overdueTasks
                        .take(5)
                        .map((task) => TaskCard(task: task, showIntern: true)),
                  ],
                ],
              );
            },
          );
        },
      ),
    );
  }
}
