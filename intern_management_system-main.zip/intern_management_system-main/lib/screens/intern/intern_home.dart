import 'package:flutter/material.dart';

import '../../models/user_model.dart';
import 'intern_dashboard.dart';
import 'intern_insights_screen.dart';
import 'intern_tasks_screen.dart';
import 'profile_screen.dart';

class InternHome extends StatefulWidget {
  const InternHome({super.key, required this.intern});

  final UserModel intern;

  @override
  State<InternHome> createState() => _InternHomeState();
}

class _InternHomeState extends State<InternHome> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      InternDashboard(
        intern: widget.intern,
        onViewAllTasks: () => setState(() => _index = 1),
      ),
      InternTasksScreen(intern: widget.intern),
      InternInsightsScreen(intern: widget.intern),
      ProfileScreen(intern: widget.intern),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (index) => setState(() => _index = index),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
          NavigationDestination(
            icon: Icon(Icons.task_alt_outlined),
            selectedIcon: Icon(Icons.task_alt),
            label: 'Tasks',
          ),
          NavigationDestination(
            icon: Icon(Icons.insights_outlined),
            selectedIcon: Icon(Icons.insights),
            label: 'Insights',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'My Profile',
          ),
        ],
      ),
    );
  }
}
