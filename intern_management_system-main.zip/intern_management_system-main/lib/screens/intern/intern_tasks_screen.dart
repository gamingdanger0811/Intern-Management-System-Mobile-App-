import 'package:flutter/material.dart';

import '../../models/task_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/progress_sheet.dart';
import '../../widgets/task_card.dart';

class InternTasksScreen extends StatefulWidget {
  const InternTasksScreen({super.key, required this.intern});

  final UserModel intern;

  @override
  State<InternTasksScreen> createState() => _InternTasksScreenState();
}

class _InternTasksScreenState extends State<InternTasksScreen> {
  String _filter = 'all';

  static const _filters = {
    'all': 'All',
    'pending': 'Pending',
    'in-progress': 'In Progress',
    'completed': 'Completed',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Tasks')),
      body: Column(
        children: [
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: _filters.entries
                  .map(
                    (entry) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ChoiceChip(
                        label: Text(entry.value),
                        selected: _filter == entry.key,
                        selectedColor: AppTheme.primary,
                        labelStyle: TextStyle(
                          color: _filter == entry.key
                              ? Colors.white
                              : Theme.of(context).colorScheme.onSurface,
                        ),
                        onSelected: (_) => setState(() => _filter = entry.key),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
          Expanded(
            child: StreamBuilder<List<TaskModel>>(
              stream: FirestoreService().internTasksStream(widget.intern.uid),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        'Could not load tasks:\n${snapshot.error}',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }
                final tasks = (snapshot.data ?? [])
                    .where((task) => _filter == 'all' || task.status == _filter)
                    .toList();
                if (tasks.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.task_outlined,
                          size: 72,
                          color: Colors.grey.shade400,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'No tasks found',
                          style: TextStyle(color: Colors.grey.shade600),
                        ),
                      ],
                    ),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: tasks.length,
                  itemBuilder: (context, index) => TaskCard(
                    task: tasks[index],
                    onTap: () => showProgressSheet(context, tasks[index]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
