import 'package:flutter/material.dart';

import '../../models/task_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_widgets.dart';
import '../../widgets/progress_sheet.dart';
import '../../widgets/task_card.dart';

class InternDashboard extends StatelessWidget {
  const InternDashboard({
    super.key,
    required this.intern,
    required this.onViewAllTasks,
  });

  final UserModel intern;
  final VoidCallback onViewAllTasks;

  Widget _taskCard(BuildContext context, TaskModel task) {
    return TaskCard(task: task, onTap: () => showProgressSheet(context, task));
  }

  @override
  Widget build(BuildContext context) {
    final firestore = FirestoreService();

    return Scaffold(
      body: StreamBuilder<List<TaskModel>>(
        stream: firestore.internTasksStream(intern.uid),
        builder: (context, snapshot) {
          final tasks = snapshot.data ?? [];
          final done = tasks.where((task) => task.status == 'completed').length;
          final doing = tasks
              .where((task) => task.status == 'in-progress')
              .length;
          final pending = tasks
              .where((task) => task.status == 'pending')
              .length;
          final overall = tasks.isEmpty
              ? 0
              : (tasks.fold<int>(
                          0,
                          (sum, task) => sum + task.progress.clamp(0, 100),
                        ) /
                        tasks.length)
                    .round();
          final upcoming = tasks
              .where((task) => task.status != 'completed')
              .take(3)
              .toList();
          final loading = snapshot.connectionState == ConnectionState.waiting;

          return ListView(
            padding: EdgeInsets.zero,
            children: [
              GradientHeader(
                subtitle: 'Welcome,',
                title: intern.name,
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (snapshot.hasError)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Text(
                          'Could not load tasks: ${snapshot.error}',
                          style: const TextStyle(color: AppTheme.danger),
                        ),
                      ),
                    Row(
                      children: [
                        StatCard(
                          label: 'Pending',
                          value: '$pending',
                          icon: Icons.hourglass_empty,
                          color: AppTheme.grey,
                        ),
                        const SizedBox(width: 12),
                        StatCard(
                          label: 'In Progress',
                          value: '$doing',
                          icon: Icons.autorenew,
                          color: AppTheme.warning,
                        ),
                        const SizedBox(width: 12),
                        StatCard(
                          label: 'Completed',
                          value: '$done',
                          icon: Icons.check_circle,
                          color: AppTheme.success,
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    AppCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'Overall Progress',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '$overall%',
                                style: const TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: AppTheme.primary,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: LinearProgressIndicator(
                              value: overall / 100,
                              minHeight: 10,
                              backgroundColor: Colors.grey.shade300,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '$done of ${tasks.length} tasks completed',
                            style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey.shade600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 24),
                    Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Upcoming Tasks',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: onViewAllTasks,
                          child: const Text('View all'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (loading)
                      const Padding(
                        padding: EdgeInsets.all(32),
                        child: Center(child: CircularProgressIndicator()),
                      )
                    else if (tasks.isEmpty)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 32),
                        child: Center(
                          child: Column(
                            children: [
                              Icon(
                                Icons.task_outlined,
                                size: 72,
                                color: Colors.grey.shade400,
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'No tasks assigned yet',
                                style: TextStyle(color: Colors.grey.shade600),
                              ),
                            ],
                          ),
                        ),
                      )
                    else if (upcoming.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 24),
                        child: Center(
                          child: Text('All tasks completed. Great work!'),
                        ),
                      )
                    else
                      ...upcoming.map((task) => _taskCard(context, task)),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
