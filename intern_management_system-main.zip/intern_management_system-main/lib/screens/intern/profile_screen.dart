import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/confirm_logout.dart';
import '../../widgets/theme_selector.dart';

class ProfileScreen extends StatefulWidget {
  final UserModel intern;

  const ProfileScreen({super.key, required this.intern});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late String _name = widget.intern.name;
  late String _phone = widget.intern.phone;
  late String _university = widget.intern.university;
  late String _semester = widget.intern.semester;
  late String _domain = widget.intern.domain;
  bool _saving = false;

  static const _semesters = ['1', '2', '3', '4', '5', '6', '7', '8'];
  static const _domains = [
    'Flutter',
    'Web Development',
    'Android',
    'AI / ML',
    'Data Science',
    'Cyber Security',
    'UI/UX',
    'Other',
  ];

  Widget _row(IconData icon, String label, String value) {
    return ListTile(
      leading: Icon(icon, color: AppTheme.primary),
      title: Text(label, style: const TextStyle(fontSize: 12)),
      subtitle: Text(
        value.isEmpty ? '-' : value,
        style: const TextStyle(fontSize: 16),
      ),
    );
  }

  Future<void> _edit() async {
    final nameC = TextEditingController(text: _name);
    final phoneC = TextEditingController(text: _phone);
    final uniC = TextEditingController(text: _university);
    String? sem = _semesters.contains(_semester) ? _semester : null;
    String? dom = _domains.contains(_domain) ? _domain : null;
    final formKey = GlobalKey<FormState>();

    try {
      final saved = await showModalBottomSheet<bool>(
        context: context,
        isScrollControlled: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        builder: (ctx) => StatefulBuilder(
          builder: (ctx, setSheet) => Padding(
            padding: EdgeInsets.fromLTRB(
              20,
              20,
              20,
              MediaQuery.of(ctx).viewInsets.bottom + 20,
            ),
            child: SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Edit Profile',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: nameC,
                      decoration: const InputDecoration(
                        labelText: 'Name',
                        prefixIcon: Icon(Icons.person_outline),
                      ),
                      validator: (v) => (v == null || v.trim().isEmpty)
                          ? 'Zaroori hai'
                          : null,
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: phoneC,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                        labelText: 'Phone',
                        prefixIcon: Icon(Icons.phone_outlined),
                      ),
                      validator: (v) => (v != null && v.trim().length >= 10)
                          ? null
                          : 'Sahi phone number likho',
                    ),
                    const SizedBox(height: 14),
                    TextFormField(
                      controller: uniC,
                      decoration: const InputDecoration(
                        labelText: 'University',
                        prefixIcon: Icon(Icons.school_outlined),
                      ),
                      validator: (v) => (v == null || v.trim().isEmpty)
                          ? 'Zaroori hai'
                          : null,
                    ),
                    const SizedBox(height: 14),
                    DropdownButtonFormField<String>(
                      initialValue: sem,
                      decoration: const InputDecoration(
                        labelText: 'Semester',
                        prefixIcon: Icon(Icons.format_list_numbered),
                      ),
                      items: _semesters
                          .map(
                            (s) => DropdownMenuItem(
                              value: s,
                              child: Text('Semester $s'),
                            ),
                          )
                          .toList(),
                      onChanged: (v) => setSheet(() => sem = v),
                      validator: (v) => v == null ? 'Semester chuno' : null,
                    ),
                    const SizedBox(height: 14),
                    DropdownButtonFormField<String>(
                      initialValue: dom,
                      decoration: const InputDecoration(
                        labelText: 'Domain / Skill',
                        prefixIcon: Icon(Icons.code),
                      ),
                      items: _domains
                          .map(
                            (d) => DropdownMenuItem(value: d, child: Text(d)),
                          )
                          .toList(),
                      onChanged: (v) => setSheet(() => dom = v),
                      validator: (v) => v == null ? 'Domain chuno' : null,
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: () {
                          if (formKey.currentState!.validate()) {
                            Navigator.pop(ctx, true);
                          }
                        },
                        child: const Text('Save'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );

      if (saved != true || !mounted) return;
      setState(() => _saving = true);
      await FirestoreService().updateOwnProfile(widget.intern.uid, {
        'name': nameC.text.trim(),
        'phone': phoneC.text.trim(),
        'university': uniC.text.trim(),
        'semester': sem ?? '',
        'domain': dom ?? '',
        'department': dom ?? '',
      });
      if (!mounted) return;
      setState(() {
        _name = nameC.text.trim();
        _phone = phoneC.text.trim();
        _university = uniC.text.trim();
        _semester = sem ?? '';
        _domain = dom ?? '';
      });
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Profile update ho gaya')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      nameC.dispose();
      phoneC.dispose();
      uniC.dispose();
      if (mounted && _saving) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final u = widget.intern;
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: _saving ? null : _edit,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => confirmLogout(context),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: CircleAvatar(
              radius: 44,
              backgroundColor: AppTheme.primary.withValues(alpha: 0.12),
              child: Text(
                _name.isNotEmpty ? _name[0].toUpperCase() : '?',
                style: const TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primary,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Text(
              _name,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            margin: EdgeInsets.zero,
            child: Column(
              children: [
                _row(Icons.email, 'Email', u.email),
                _row(Icons.phone, 'Phone', _phone),
                _row(Icons.school, 'University', _university),
                _row(Icons.format_list_numbered, 'Semester', _semester),
                _row(
                  Icons.business,
                  'Department',
                  _domain.isEmpty ? u.department : _domain,
                ),
                _row(Icons.code, 'Domain', _domain),
                _row(
                  Icons.calendar_today,
                  'Joining Date',
                  u.joinDate == null
                      ? ''
                      : DateFormat('dd MMM yyyy').format(u.joinDate!),
                ),
                _row(
                  Icons.timelapse,
                  'Duration',
                  '${u.durationMonths} month(s)',
                ),
                _row(Icons.flag, 'Status', u.status),
              ],
            ),
          ),
          const SizedBox(height: 12),
          const ThemeSelectorCard(),
        ],
      ),
    );
  }
}
