import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../models/task_model.dart';
import '../../models/user_model.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/app_widgets.dart';
import '../../widgets/status_pie_card.dart';

class InternInsightsScreen extends StatelessWidget {
  const InternInsightsScreen({super.key, required this.intern});

  final UserModel intern;

  Widget _priorityRow(String priority, int count, int total) {
    final label = '${priority[0].toUpperCase()}${priority.substring(1)}';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          SizedBox(width: 64, child: Text(label)),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: total == 0 ? 0 : count / total,
                minHeight: 8,
                color: AppTheme.priorityColor(priority),
                backgroundColor: Colors.grey.shade300,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Text('$count'),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Insights')),
      body: StreamBuilder<List<TaskModel>>(
        stream: FirestoreService().internTasksStream(intern.uid),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'Could not load insights:\n${snapshot.error}',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          final tasks = snapshot.data ?? [];
          if (tasks.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.insights_outlined,
                      size: 72,
                      color: Colors.grey.shade400,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'No insights yet',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Insights will appear once tasks are assigned to you.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey.shade600),
                    ),
                  ],
                ),
              ),
            );
          }

          final now = DateTime.now();
          final completed = tasks
              .where((task) => task.status == 'completed')
              .length;
          final overdue = tasks
              .where(
                (task) =>
                    task.status != 'completed' && task.dueDate.isBefore(now),
              )
              .length;
          final completion = (completed / tasks.length * 100).round();
          final averageProgress =
              (tasks.fold<int>(
                        0,
                        (sum, task) => sum + task.progress.clamp(0, 100),
                      ) /
                      tasks.length)
                  .round();
          final upcoming = tasks
              .where(
                (task) =>
                    task.status != 'completed' && !task.dueDate.isBefore(now),
              )
              .toList();

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                children: [
                  StatCard(
                    label: 'Completion',
                    value: '$completion%',
                    icon: Icons.check_circle,
                    color: AppTheme.success,
                  ),
                  const SizedBox(width: 12),
                  StatCard(
                    label: 'Avg. Progress',
                    value: '$averageProgress%',
                    icon: Icons.trending_up,
                    color: AppTheme.primary,
                  ),
                  const SizedBox(width: 12),
                  StatCard(
                    label: 'Overdue',
                    value: '$overdue',
                    icon: Icons.warning_amber_rounded,
                    color: AppTheme.danger,
                  ),
                ],
              ),
              const SizedBox(height: 16),
              StatusPieCard(tasks: tasks),
              const SizedBox(height: 16),
              AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Tasks by Priority',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    for (final priority in ['high', 'medium', 'low'])
                      _priorityRow(
                        priority,
                        tasks.where((task) => task.priority == priority).length,
                        tasks.length,
                      ),
                  ],
                ),
              ),
              if (upcoming.isNotEmpty) ...[
                const SizedBox(height: 16),
                AppCard(
                  child: Row(
                    children: [
                      const Icon(Icons.event, color: AppTheme.primary),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Next deadline',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey.shade600,
                              ),
                            ),
                            Text(
                              upcoming.first.title,
                              style: const TextStyle(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            Text(
                              DateFormat('dd MMM yyyy')
                                  .format(upcoming.first.dueDate),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}
