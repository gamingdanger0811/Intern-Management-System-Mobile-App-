import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

class DefaultFirebaseOptions {
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyBI5QTh5Q6QUYVEzqtYXhtrxQe31uzUPhc',
    appId: '1:949649849695:web:55eba74c766daf00724aea',
    messagingSenderId: '949649849695',
    projectId: 'intern-management-system-f6423',
    authDomain: 'intern-management-system-f6423.firebaseapp.com',
    storageBucket: 'intern-management-system-f6423.firebasestorage.app',
    measurementId: 'G-ZW20NQD8BE',
  );
}
