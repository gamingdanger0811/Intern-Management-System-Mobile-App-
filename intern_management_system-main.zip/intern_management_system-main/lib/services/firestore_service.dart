import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import '../models/task_model.dart';
import '../models/user_model.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<UserModel>> internsStream() {
    return _db
        .collection('users')
        .where('role', isEqualTo: 'intern')
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((doc) => UserModel.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  Future<void> updateIntern(String uid, Map<String, dynamic> data) =>
      _db.collection('users').doc(uid).update(data);

  Future<void> updateOwnProfile(String uid, Map<String, dynamic> data) =>
      _db.collection('users').doc(uid).update(data);

  Future<void> deleteIntern(String uid) =>
      _db.collection('users').doc(uid).delete();

  Future<void> addTask(TaskModel task) =>
      _db.collection('tasks').add(task.toMap());

  // Ek saath kai tasks (har intern ke liye ek). Ya sab bante hain ya koi nahi.
  Future<void> addTasks(List<TaskModel> tasks) async {
    final batch = _db.batch();
    for (final t in tasks) {
      batch.set(_db.collection('tasks').doc(), t.toMap());
    }
    await batch.commit();
  }

  Stream<List<TaskModel>> allTasksStream() {
    return _db.collection('tasks').snapshots().map((snapshot) {
      final tasks = snapshot.docs
          .map((doc) => TaskModel.fromMap(doc.id, doc.data()))
          .toList();
      tasks.sort((a, b) => a.dueDate.compareTo(b.dueDate));
      return tasks;
    });
  }

  Stream<List<TaskModel>> internTasksStream(String uid) {
    return _db
        .collection('tasks')
        .where('assignedTo', isEqualTo: uid)
        .snapshots()
        .map((snapshot) {
          final tasks = snapshot.docs
              .map((doc) => TaskModel.fromMap(doc.id, doc.data()))
              .toList();
          tasks.sort((a, b) => a.dueDate.compareTo(b.dueDate));
          return tasks;
        });
  }

  Future<void> updateTaskProgress(String id, int progress) {
    if (progress < 0 || progress > 100) {
      throw RangeError.range(progress, 0, 100, 'progress');
    }
    final status = progress >= 100
        ? 'completed'
        : (progress == 0 ? 'pending' : 'in-progress');
    return _db.collection('tasks').doc(id).update({
      'progress': progress,
      'status': status,
    });
  }

  Future<void> deleteTask(String id) =>
      _db.collection('tasks').doc(id).delete();

  Future<void> addIntern({
    required String email,
    required String password,
    required Map<String, dynamic> data,
  }) async {
    FirebaseApp secondary;
    try {
      secondary = Firebase.app('secondary');
    } on FirebaseException catch (e) {
      if (e.code != 'no-app') rethrow;
      secondary = await Firebase.initializeApp(
        name: 'secondary',
        options: Firebase.app().options,
      );
    }

    final secondaryAuth = FirebaseAuth.instanceFor(app: secondary);
    try {
      final credential = await secondaryAuth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      await _db.collection('users').doc(credential.user!.uid).set({
        ...data,
        'email': email.trim(),
        'role': 'intern',
        'createdAt': FieldValue.serverTimestamp(),
      });
    } finally {
      await secondaryAuth.signOut();
    }
  }
}
