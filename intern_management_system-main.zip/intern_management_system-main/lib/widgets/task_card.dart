import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/task_model.dart';
import '../theme/app_theme.dart';

class TaskCard extends StatelessWidget {
  const TaskCard({
    super.key,
    required this.task,
    this.showIntern = false,
    this.onTap,
  });

  final TaskModel task;
  final bool showIntern;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final priorityColor = AppTheme.priorityColor(task.priority);
    final statusColor = AppTheme.statusColor(task.status);
    final progress = task.progress.clamp(0, 100);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      task.title,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  _badge(
                    color: priorityColor,
                    icon: Icons.flag,
                    label: task.priority,
                  ),
                  const SizedBox(width: 6),
                  _badge(color: statusColor, label: task.status),
                ],
              ),
              if (showIntern) ...[
                const SizedBox(height: 6),
                Text('Intern: ${task.assignedToName}'),
              ],
              const SizedBox(height: 6),
              Text('Due: ${DateFormat('dd MMM yyyy').format(task.dueDate)}'),
              if (task.description.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(
                  task.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: Theme.of(context).hintColor),
                ),
              ],
              const SizedBox(height: 12),
              LinearProgressIndicator(
                value: progress / 100,
                minHeight: 7,
                borderRadius: BorderRadius.circular(8),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.centerRight,
                child: Text('$progress%'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _badge({required Color color, required String label, IconData? icon}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 12, color: color),
            const SizedBox(width: 2),
          ],
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
