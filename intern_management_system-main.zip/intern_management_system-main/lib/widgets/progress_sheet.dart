import 'package:flutter/material.dart';

import '../models/task_model.dart';
import '../services/firestore_service.dart';
import '../theme/app_theme.dart';

void showProgressSheet(BuildContext context, TaskModel task) {
  var value = task.progress.clamp(0, 100).toDouble();
  var saving = false;

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (sheetContext) => StatefulBuilder(
      builder: (sheetContext, setSheetState) => Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          20,
          20,
          MediaQuery.of(sheetContext).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              task.title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            if (task.description.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                task.description,
                style: TextStyle(color: Colors.grey.shade600),
              ),
            ],
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Progress',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
                Text(
                  '${value.round()}%',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: AppTheme.primary,
                  ),
                ),
              ],
            ),
            Slider(
              value: value,
              min: 0,
              max: 100,
              divisions: 20,
              label: '${value.round()}%',
              onChanged: saving
                  ? null
                  : (newValue) => setSheetState(() => value = newValue),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: saving
                    ? null
                    : () async {
                        setSheetState(() => saving = true);
                        try {
                          await FirestoreService().updateTaskProgress(
                            task.id,
                            value.round(),
                          );
                          if (sheetContext.mounted) {
                            Navigator.pop(sheetContext);
                          }
                        } catch (error) {
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Update fail: $error')),
                            );
                          }
                        } finally {
                          if (sheetContext.mounted) {
                            setSheetState(() => saving = false);
                          }
                        }
                      },
                child: saving
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Text('Save Progress'),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
