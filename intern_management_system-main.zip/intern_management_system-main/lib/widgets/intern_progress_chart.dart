import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../models/task_model.dart';
import '../models/user_model.dart';
import '../theme/app_theme.dart';

class InternProgressChart extends StatelessWidget {
  const InternProgressChart({
    super.key,
    required this.interns,
    required this.tasks,
  });

  final List<UserModel> interns;
  final List<TaskModel> tasks;

  @override
  Widget build(BuildContext context) {
    final data = <MapEntry<String, double>>[];
    for (final intern in interns) {
      final internTasks = tasks
          .where((task) => task.assignedTo == intern.uid)
          .toList();
      if (internTasks.isEmpty) continue;
      final average =
          internTasks.fold<int>(
            0,
            (sum, task) => sum + task.progress.clamp(0, 100),
          ) /
          internTasks.length;
      final nameParts = intern.name.trim().split(RegExp(r'\s+'));
      final firstName = nameParts.isEmpty || nameParts.first.isEmpty
          ? '?'
          : nameParts.first;
      data.add(MapEntry(firstName, average));
    }
    data.sort((a, b) => b.value.compareTo(a.value));
    final shown = data.take(6).toList();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Intern Progress',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(
              'Average task completion per intern',
              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
            ),
            const SizedBox(height: 16),
            if (shown.isEmpty)
              const SizedBox(
                height: 120,
                child: Center(child: Text('Abhi data nahi hai')),
              )
            else
              SizedBox(
                height: 200,
                child: BarChart(
                  BarChartData(
                    maxY: 100,
                    alignment: BarChartAlignment.spaceAround,
                    gridData: const FlGridData(
                      show: true,
                      drawVerticalLine: false,
                    ),
                    borderData: FlBorderData(show: false),
                    titlesData: FlTitlesData(
                      topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      rightTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 32,
                          interval: 25,
                          getTitlesWidget: (value, _) => Text(
                            '${value.toInt()}',
                            style: const TextStyle(fontSize: 10),
                          ),
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          getTitlesWidget: (value, _) {
                            final index = value.toInt();
                            if (index < 0 || index >= shown.length) {
                              return const SizedBox.shrink();
                            }
                            return Padding(
                              padding: const EdgeInsets.only(top: 6),
                              child: Text(
                                shown[index].key,
                                style: const TextStyle(fontSize: 10),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    barGroups: [
                      for (var index = 0; index < shown.length; index++)
                        BarChartGroupData(
                          x: index,
                          barRods: [
                            BarChartRodData(
                              toY: shown[index].value,
                              width: 18,
                              borderRadius: BorderRadius.circular(6),
                              color: AppTheme.primary,
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
