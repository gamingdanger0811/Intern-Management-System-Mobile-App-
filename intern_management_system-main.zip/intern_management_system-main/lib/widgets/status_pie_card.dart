import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../models/task_model.dart';
import '../theme/app_theme.dart';

class StatusPieCard extends StatelessWidget {
  const StatusPieCard({super.key, required this.tasks});

  final List<TaskModel> tasks;

  Widget _legend(Color color, String label, int count) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 8),
        Text('$label: $count'),
      ],
    ),
  );

  @override
  Widget build(BuildContext context) {
    final pending = tasks.where((task) => task.status == 'pending').length;
    final inProgress = tasks
        .where((task) => task.status == 'in-progress')
        .length;
    final completed = tasks.where((task) => task.status == 'completed').length;

    PieChartSectionData section(int count, Color color) => PieChartSectionData(
      value: count.toDouble(),
      color: color,
      radius: 28,
      title: '$count',
      titleStyle: const TextStyle(
        color: Colors.white,
        fontWeight: FontWeight.bold,
      ),
    );

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Task Status',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            if (tasks.isEmpty)
              const SizedBox(
                height: 100,
                child: Center(child: Text('No data yet')),
              )
            else
              Row(
                children: [
                  SizedBox(
                    height: 120,
                    width: 120,
                    child: PieChart(
                      PieChartData(
                        sectionsSpace: 2,
                        centerSpaceRadius: 28,
                        sections: [
                          if (pending > 0) section(pending, AppTheme.grey),
                          if (inProgress > 0)
                            section(inProgress, AppTheme.warning),
                          if (completed > 0)
                            section(completed, AppTheme.success),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _legend(AppTheme.grey, 'Pending', pending),
                        _legend(AppTheme.warning, 'In Progress', inProgress),
                        _legend(AppTheme.success, 'Completed', completed),
                      ],
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
