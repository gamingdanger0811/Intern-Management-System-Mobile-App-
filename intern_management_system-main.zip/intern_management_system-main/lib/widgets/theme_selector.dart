import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/theme_provider.dart';
import '../theme/app_theme.dart';
import 'app_widgets.dart';

class ThemeSelectorCard extends StatelessWidget {
  const ThemeSelectorCard({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = context.watch<ThemeProvider>().mode == ThemeMode.dark;
    return AppCard(
      padding: EdgeInsets.zero,
      child: ListTile(
        leading: Icon(
          isDark ? Icons.dark_mode : Icons.light_mode,
          color: AppTheme.primary,
        ),
        title: const Text('Theme'),
        subtitle: Text(isDark ? 'Dark' : 'Light'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showThemeSheet(context),
      ),
    );
  }
}

void _showThemeSheet(BuildContext context) {
  showModalBottomSheet<void>(
    context: context,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => const SafeArea(
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'Choose theme',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 8),
            _ThemeOptions(),
          ],
        ),
      ),
    ),
  );
}

class _ThemeOptions extends StatelessWidget {
  const _ThemeOptions();

  static const _items = [
    (ThemeMode.light, 'Light', Icons.light_mode),
    (ThemeMode.dark, 'Dark', Icons.dark_mode),
  ];

  Future<void> _setMode(BuildContext context, ThemeMode mode) async {
    try {
      await context.read<ThemeProvider>().setMode(mode);
      if (context.mounted) Navigator.pop(context);
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save theme preference: $error')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ThemeProvider>();
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (provider.loadError case final error?)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              'Could not load saved theme preference: $error',
              style: const TextStyle(color: AppTheme.danger),
            ),
          ),
        ..._items.map((item) {
          final selected = provider.mode == item.$1;
          return ListTile(
            leading: Icon(item.$3, color: selected ? AppTheme.primary : null),
            title: Text(item.$2),
            trailing: Icon(
              selected ? Icons.check_circle : Icons.circle_outlined,
              color: selected ? AppTheme.primary : Colors.grey,
            ),
            onTap: () => _setMode(context, item.$1),
          );
        }),
      ],
    );
  }
}
