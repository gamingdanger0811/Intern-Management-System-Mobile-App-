import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:intern_management_system/providers/theme_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Future<void> waitForInitialLoad(ThemeProvider provider) {
    final loaded = Completer<void>();
    void listener() {
      if (!loaded.isCompleted) loaded.complete();
    }

    provider.addListener(listener);
    return loaded.future.whenComplete(() => provider.removeListener(listener));
  }

  test('theme selection persists across provider instances', () async {
    SharedPreferences.setMockInitialValues({});

    final provider = ThemeProvider();
    final initialLoad = waitForInitialLoad(provider);
    await initialLoad;
    expect(provider.mode, ThemeMode.light);

    await provider.setMode(ThemeMode.dark);
    expect(provider.mode, ThemeMode.dark);

    final restoredProvider = ThemeProvider();
    await waitForInitialLoad(restoredProvider);
    expect(restoredProvider.mode, ThemeMode.dark);
  });

  test('unknown saved mode falls back to light', () async {
    SharedPreferences.setMockInitialValues({'themeMode': 'unknown'});

    final provider = ThemeProvider();
    await waitForInitialLoad(provider);

    expect(provider.mode, ThemeMode.light);
  });
}
