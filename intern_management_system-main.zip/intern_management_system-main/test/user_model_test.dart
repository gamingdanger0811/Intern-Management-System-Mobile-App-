import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:intern_management_system/models/user_model.dart';

void main() {
  group('UserModel.fromMap', () {
    test(
      'applies defaults to existing user records without profile fields',
      () {
        final user = UserModel.fromMap('intern-1', {
          'name': 'Ayesha',
          'email': 'ayesha@example.com',
          'role': 'intern',
          'department': 'Engineering',
        });

        expect(user.uid, 'intern-1');
        expect(user.phone, isEmpty);
        expect(user.university, isEmpty);
        expect(user.semester, isEmpty);
        expect(user.domain, isEmpty);
        expect(user.joinDate, isNull);
        expect(user.durationMonths, 3);
        expect(user.status, 'active');
      },
    );

    test('reads the extended internship profile fields', () {
      final joinDate = DateTime(2026, 1, 15);
      final user = UserModel.fromMap('intern-2', {
        'name': 'Ayesha',
        'email': 'ayesha@example.com',
        'role': 'intern',
        'department': 'Engineering',
        'phone': '1234567890',
        'university': 'Example University',
        'semester': '6',
        'domain': 'Flutter',
        'joinDate': Timestamp.fromDate(joinDate),
        'durationMonths': 6,
        'status': 'active',
      });

      expect(user.phone, '1234567890');
      expect(user.university, 'Example University');
      expect(user.semester, '6');
      expect(user.domain, 'Flutter');
      expect(user.joinDate, joinDate);
      expect(user.durationMonths, 6);
      expect(user.status, 'active');
    });
  });
}
