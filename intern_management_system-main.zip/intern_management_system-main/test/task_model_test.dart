import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:intern_management_system/models/task_model.dart';

void main() {
  test('legacy tasks default to medium priority', () {
    final task = TaskModel.fromMap('task-1', {
      'title': 'Build dashboard',
      'description': '',
      'assignedTo': 'intern-1',
      'assignedToName': 'Ayesha',
      'dueDate': Timestamp.fromDate(DateTime(2026, 10, 30)),
    });

    expect(task.priority, 'medium');
  });

  test('reads and serializes priority', () {
    final dueDate = DateTime(2026, 10, 30);
    final task = TaskModel.fromMap('task-2', {
      'title': 'Build dashboard',
      'description': '',
      'assignedTo': 'intern-1',
      'assignedToName': 'Ayesha',
      'dueDate': Timestamp.fromDate(dueDate),
      'priority': 'high',
    });

    expect(task.priority, 'high');
    expect(task.toMap()['priority'], 'high');
  });

  test('unknown priorities fall back to medium', () {
    final task = TaskModel.fromMap('task-3', {'priority': 'urgent'});

    expect(task.priority, 'medium');
  });
}
