// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:intern_management_system/main.dart';

void main() {
  testWidgets('shows Firebase initialization errors', (
    WidgetTester tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    final initialization = Completer<FirebaseApp>();
    await tester.pumpWidget(
      MyApp(firebaseInitialization: initialization.future),
    );
    initialization.completeError(Exception('test configuration error'));
    await tester.pumpAndSettle();

    expect(
      find.textContaining('Firebase initialize nahi ho saka'),
      findsOneWidget,
    );
    expect(find.textContaining('test configuration error'), findsOneWidget);
  });
}
