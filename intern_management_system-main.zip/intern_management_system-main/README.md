# Intern Management System

A mobile app built with Flutter and Firebase to manage intern profiles,
assigned tasks and progress in one place.

## Features

**Intern**
- Secure login, account creation and password reset (Firebase Authentication)
- Dashboard with task stats and overall progress
- View assigned tasks, filter by status and update progress
- Insights: task status chart, priority breakdown, overdue tasks
- Edit own profile

**Admin**
- Add, edit, search and delete interns
- Assign a task to one or many interns at once
- Task priority (low, medium, high) and due dates
- Dashboard stats and insights (completion rate, per-intern progress, overdue tasks)

**General**
- Role-based access (admin / intern) with Firestore security rules
- Light and dark theme
- Real-time updates with Cloud Firestore

## Tech Stack
- Flutter (Dart)
- Firebase Authentication
- Cloud Firestore
- Provider (state management)
- fl_chart (charts)

## Database Structure
- `users`: name, email, role, phone, university, semester, domain, department, joinDate, durationMonths, status
- `tasks`: title, description, assignedTo, assignedToName, dueDate, priority, status, progress, createdAt

## Setup
1. Clone the repository and run `flutter pub get`.
2. Create a Firebase project, enable Email/Password authentication and create a Firestore database.
3. Add your Firebase config:
   - Android: place `google-services.json` in `android/app/`
   - Run `flutterfire configure` to generate `lib/firebase_options.dart`
4. Publish the Firestore security rules from the `firestore.rules` file.
5. Create the first admin manually: add a user in Firebase Authentication, then create
   a document in `users/{uid}` with `role: "admin"`, `name` and `email`.
6. Run the app with `flutter run`.

## Screens
Add your screenshots here (login, admin dashboard, assign task, intern dashboard, insights, profile).

## Author
Ateeq Ur Rahman
